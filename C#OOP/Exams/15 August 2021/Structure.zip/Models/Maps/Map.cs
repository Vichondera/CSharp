namespace CarRacing.Models.Maps
{
    using System;
    using CarRacing.Models.Maps.Contracts;
    using CarRacing.Models.Racers.Contracts;

    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            throw new NotImplementedException();
        }
    }
}